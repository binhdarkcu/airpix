<?php
class Element_Password extends Element_Textbox {
	protected $_attributes = array("type" => "password");
}
