<?php get_header()?>
<div class="upload">

<!---728x90--->

    <!-- container -->
    <div class="container">
        <div class="upload-grids">
            <div class="upload-right">
                <div class="upload-file">
                    <div class="services-icon">
                        <span class="glyphicon glyphicon-open" aria-hidden="true"></span>
                    </div>
                    <input type="file" value="Choose file..">
                </div>
                <div class="upload-info">
                    <h5>Select files to upload</h5>
                    <span>or</span>
                    <p>Drag and drop files</p>
                </div>
            </div>

<!---728x90--->


        </div>
    </div>
    <!-- //container -->
</div>
<!-- //upload -->
<?php get_footer()?>
