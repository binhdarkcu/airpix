<?php get_header()?>
<?php
    echo do_shortcode('[evp_embed_video url="http://localhost:8080/wp-content/uploads/uploaded-videos/2ecf7dd304bf8234a8dbf993a9b683123ccda0831521599053.mp4" template="mediaelement"]');
?>
<?php get_footer()?>
